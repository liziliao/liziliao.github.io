###################################################################################


The dataset is a SQL file. It can be easily used by �Load SQL file�.

By 'Load SQL file', a database named "brandmonitor" will be created which contains two tables "singtel_twitter" and "starhub_twitter".

Table Structure is as below (example for create singtel_twitter table):

CREATE TABLE `singtel_twitter` (
	`id` TEXT NOT NULL,  # tweet id
	`like_count` INT(10) UNSIGNED NOT NULL,  # number of like
	`retct` INT(10) UNSIGNED NULL DEFAULT NULL, # number of retweet
	`content` TEXT NULL,  # tweet content
	`uid` TEXT NULL, # user id
	`uurl` TEXT NULL, # user url
	`uname` TEXT NULL, # user name
	`type` TEXT NULL, # tweet
	`lang` TEXT NULL, # language
	`url` TEXT NULL, # tweet url
	`pub_time` TEXT NULL, # pub time
	`fet_time` TEXT NULL, # explicit form of pub time
	`source` TEXT NULL, # twitter
	`account` TEXT NULL, # user account
	`head` TEXT NULL, # user profile image link
	`image` TEXT NULL, 
	`video` TEXT NULL 
)
COLLATE='latin1_swedish_ci'
ENGINE=InnoDB
;
